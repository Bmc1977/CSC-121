I finished this all with VSCode so I hope it runs in PyCharm. If not can I turn it in again after making it work on my windows machine?

P.S. My animation can be found in the animation.py file.

Thank you!